import AuthController from './AuthController'
import UserController from './UserController'
import ConversationController from './ConversationController'
import MessageController from './MessageController'

const Api = {
    AuthController: Object.assign(AuthController, AuthController),
    UserController: Object.assign(UserController, UserController),
    ConversationController: Object.assign(ConversationController, ConversationController),
    MessageController: Object.assign(MessageController, MessageController),
}

export default Api